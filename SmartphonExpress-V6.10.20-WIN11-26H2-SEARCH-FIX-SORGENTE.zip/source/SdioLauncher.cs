using System.Diagnostics;
using System.Text.RegularExpressions;

namespace SmartphonExpressWindowsTool;

internal static class SdioLauncher
{
    internal static Task StartAsync(string selectedPath)
    {
        var completion = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        // ShellExecute can wait on Windows shell/antivirus. Keep it off the UI,
        // on an STA thread, and never wait for the launched application to exit.
        var thread = new Thread(() =>
        {
            try
            {
                string executable = Path.GetFullPath(selectedPath);
                if (!Regex.IsMatch(Path.GetFileName(executable), @"^SDIO(?:_[A-Za-z0-9_-]+)?\.exe$", RegexOptions.IgnoreCase))
                    throw new InvalidOperationException("Seleziona SDIO.exe o SDIO_x64.exe dal pacchetto SDIO estratto.");
                if (!File.Exists(executable))
                    throw new FileNotFoundException("Eseguibile SDIO non trovato. Estrai l'intero pacchetto e seleziona nuovamente il file.", executable);
                using var process = Process.Start(new ProcessStartInfo
                {
                    FileName = executable,
                    WorkingDirectory = Path.GetDirectoryName(executable)!,
                    UseShellExecute = true
                });
                if (process is null) throw new InvalidOperationException("Windows non ha restituito un processo SDIO.");
                completion.SetResult();
            }
            catch (Exception ex) { completion.SetException(ex); }
        }) { IsBackground = true, Name = "SDIO launcher" };
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        return completion.Task;
    }
}
