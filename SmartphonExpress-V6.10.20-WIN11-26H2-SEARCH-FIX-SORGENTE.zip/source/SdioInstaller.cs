using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SmartphonExpressWindowsTool;

/// <summary>Downloads the portable APPLICATION ONLY from the publisher's HTTPS domain.
/// Driver packs and driver installation are always managed interactively by SDIO.</summary>
internal static class SdioInstaller
{
    private const string PublisherPage = "https://www.glenn.delahoy.com/snappy-driver-installer-origin/";
    private const string PublisherHost = "www.glenn.delahoy.com";
    private const long MaxArchiveBytes = 150L * 1024 * 1024;
    private const long MaxExtractedBytes = 400L * 1024 * 1024;
    internal static string InstallDirectory => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "SmartphonExpress", "Tools", "SDIO");

    internal static async Task<string> EnsureInstalledAsync(IProgress<string>? progress = null, CancellationToken cancellationToken = default)
    {
        var existing = SdioLocator.FindInstalled();
        if (existing is not null) return existing;

        using var http = new HttpClient(new HttpClientHandler { AllowAutoRedirect = false })
        { Timeout = TimeSpan.FromMinutes(5) };
        http.DefaultRequestHeaders.UserAgent.ParseAdd("SmartphonExpress-Windows-Tool/6.10.14");
        progress?.Report("SDIO: ricerca del pacchetto sul sito ufficiale…");
        using var pageResponse = await http.GetAsync(PublisherPage, cancellationToken);
        pageResponse.EnsureSuccessStatusCode();
        var html = await pageResponse.Content.ReadAsStringAsync(cancellationToken);
        // Accept only the publisher's versioned application ZIP, never torrents or driver packs.
        var matches = Regex.Matches(html, @"(?:https?://(?:www\.)?glenn\.delahoy\.com)?/downloads/sdio/SDIO_(\d+(?:\.\d+){2,4})\.zip", RegexOptions.IgnoreCase);
        if (matches.Count == 0)
            throw new InvalidOperationException("Il sito ufficiale non espone un link ZIP SDIO riconoscibile. Nessun file è stato scaricato.");
        var selected = matches.Cast<Match>()
            .OrderByDescending(m => Version.Parse(m.Groups[1].Value)).First();
        var uri = new Uri("https://" + PublisherHost + "/downloads/sdio/SDIO_" + selected.Groups[1].Value + ".zip");
        if (uri.Scheme != Uri.UriSchemeHttps || uri.Host != PublisherHost)
            throw new InvalidOperationException("Origine download SDIO non autorizzata.");

        string tempZip = Path.Combine(Path.GetTempPath(), "SmartphonExpress-SDIO-" + Guid.NewGuid().ToString("N") + ".zip");
        string staging = InstallDirectory + "-temp-" + Guid.NewGuid().ToString("N");
        string? preservedDirectory = null;
        try
        {
            progress?.Report("SDIO: download dell'applicazione ufficiale…");
            using (var response = await http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, cancellationToken))
            {
                response.EnsureSuccessStatusCode();
                if (response.Content.Headers.ContentLength > MaxArchiveBytes)
                    throw new InvalidDataException("Archivio SDIO troppo grande.");
                await using var input = await response.Content.ReadAsStreamAsync(cancellationToken);
                await using var output = File.Create(tempZip);
                var buffer = new byte[81920];
                long total = 0;
                int count;
                while ((count = await input.ReadAsync(buffer, cancellationToken)) != 0)
                {
                    total += count;
                    if (total > MaxArchiveBytes) throw new InvalidDataException("Archivio SDIO oltre il limite previsto.");
                    await output.WriteAsync(buffer.AsMemory(0, count), cancellationToken);
                }
            }
            progress?.Report("SDIO: estrazione in corso…");
            Directory.CreateDirectory(staging);
            using (var archive = ZipFile.OpenRead(tempZip))
            {
                long total = 0;
                foreach (var entry in archive.Entries)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    total += entry.Length;
                    if (total > MaxExtractedBytes) throw new InvalidDataException("Contenuto SDIO oltre il limite previsto.");
                    string target = Path.GetFullPath(Path.Combine(staging, entry.FullName.Replace('/', Path.DirectorySeparatorChar)));
                    if (!target.StartsWith(Path.GetFullPath(staging) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Percorso non valido nell'archivio SDIO.");
                    if (string.IsNullOrEmpty(entry.Name)) { Directory.CreateDirectory(target); continue; }
                    Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                    entry.ExtractToFile(target, overwrite: false);
                }
            }
            var candidates = Directory.GetFiles(staging, "SDIO*.exe", SearchOption.AllDirectories)
                .Where(SdioLocator.IsValidCandidate).ToArray();
            var chosen = candidates.OrderByDescending(p => Environment.Is64BitOperatingSystem && Path.GetFileName(p).StartsWith("SDIO_x64", StringComparison.OrdinalIgnoreCase))
                .FirstOrDefault();
            if (chosen is null) throw new InvalidDataException("Pacchetto scaricato privo di eseguibile SDIO riconosciuto.");
            // Preserve an existing installation, if another instance completed it meanwhile.
            var alreadyInstalled = SdioLocator.FindInstalled();
            if (alreadyInstalled is not null) return alreadyInstalled;
            Directory.CreateDirectory(Path.GetDirectoryName(InstallDirectory)!);
            // A previous interrupted extraction may have left an empty/incomplete folder.
            // Never delete its contents: preserve them under a timestamped backup name.
            if (Directory.Exists(InstallDirectory))
            {
                preservedDirectory = InstallDirectory + "-backup-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6];
                progress?.Report("SDIO: cartella precedente incompleta; salvataggio di sicurezza…");
                Directory.Move(InstallDirectory, preservedDirectory);
            }
            try
            {
                Directory.Move(staging, InstallDirectory);
            }
            catch
            {
                // Restore the old directory if committing the new installation fails.
                if (preservedDirectory is not null && !Directory.Exists(InstallDirectory))
                    Directory.Move(preservedDirectory, InstallDirectory);
                throw;
            }
            var installed = Path.Combine(InstallDirectory, Path.GetRelativePath(staging, chosen));
            SdioLocator.Remember(installed);
            if (preservedDirectory is not null)
                progress?.Report("SDIO: vecchia cartella conservata in " + preservedDirectory);
            progress?.Report("SDIO: installazione portatile completata.");
            return installed;
        }
        finally
        {
            try { if (File.Exists(tempZip)) File.Delete(tempZip); } catch (IOException) { }
            try { if (Directory.Exists(staging)) Directory.Delete(staging, true); } catch (IOException) { }
        }
    }
}
