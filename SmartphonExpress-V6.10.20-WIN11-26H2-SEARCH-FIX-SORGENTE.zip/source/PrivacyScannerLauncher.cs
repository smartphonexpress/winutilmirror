using System.Runtime.InteropServices;
using System.Diagnostics;

namespace SmartphonExpressWindowsTool;
internal static class PrivacyScannerLauncher
{
    public static void Start(IWin32Window owner, Action<string> log)
    {
        object? shell = null;
        try
        {
            var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SmartphonExpress", "PrivacyScanner");
            Directory.CreateDirectory(dir);
            var script = Path.Combine(dir, "PrivacyScanner.ps1");
            using (var source = typeof(PrivacyScannerLauncher).Assembly.GetManifestResourceStream("SmartphonExpress.PrivacyScanner.ps1") ?? throw new InvalidOperationException("Risorsa scanner mancante."))
            using (var dest = File.Create(script)) source.CopyTo(dest);
            var ps = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
            var args = $"-NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File \"{script}\"";
            // Delegate launch to desktop Explorer, rather than inheriting the elevated tool token.
            var type = Type.GetTypeFromProgID("Shell.Application") ?? throw new InvalidOperationException("Shell non disponibile.");
            shell = Activator.CreateInstance(type) ?? throw new InvalidOperationException("Shell non disponibile.");
            dynamic sh = shell;
            dynamic windows = sh.Windows();
            object loc = 0, root = 0; int hwnd = 0;
            dynamic desktop = windows.FindWindowSW(ref loc, ref root, 8, out hwnd, 1);
            if (desktop == null) throw new InvalidOperationException("Desktop Explorer non disponibile.");
            desktop.Document.Application.ShellExecute(ps, args, dir, "open", 1);
            log("PRIVACY: avvio richiesto a Explorer (Outlook classico).");
        }
        catch (Exception ex)
        {
            log("PRIVACY: " + ex.Message);
            MessageBox.Show(owner, "Avvio non riuscito. Usa il pacchetto Privacy Scanner autonomo senza amministratore.\n\n" + ex.Message, "Privacy Scanner", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        finally { if (shell != null && Marshal.IsComObject(shell)) Marshal.ReleaseComObject(shell); }
    }
}
