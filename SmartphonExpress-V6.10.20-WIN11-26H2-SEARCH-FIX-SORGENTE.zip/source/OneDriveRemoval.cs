using System.Diagnostics;

namespace SmartphonExpressWindowsTool;

internal static class OneDriveRemoval
{
    public static void Start(IWin32Window owner, Action<string> Log)
    {
        const string title = "SmartphonExpress - Rimozione OneDrive";
        var confirm = MessageBox.Show(owner,
            "Questa utility esegue una rimozione completa di OneDrive.\n\n" +
            "Lo script può:\n" +
            "• creare un backup dei file OneDrive;\n" +
            "• ripristinare Desktop, Documenti e Immagini su percorsi locali;\n" +
            "• disinstallare OneDrive personale/aziendale;\n" +
            "• rimuoverlo da Esplora file;\n" +
            "• bloccarne la reinstallazione automatica.\n\n" +
            "La funzione è volutamente separata da 'Esegui selezionati' e non viene inclusa da 'Seleziona tutti'.\n\n" +
            "Vuoi avviare la procedura?",
            title,
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Warning,
            MessageBoxDefaultButton.Button2);

        if (confirm != DialogResult.Yes)
        {
            Log("ONEDRIVE: operazione annullata dall'utente.");
            return;
        }

        try
        {
            var baseDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                "SmartphonExpress", "OneDriveRemoval");
            Directory.CreateDirectory(baseDir);

            var scriptPath = Path.Combine(baseDir, "Remove-OneDrive.ps1");
            var asm = typeof(OneDriveRemoval).Assembly;
            using var stream = asm.GetManifestResourceStream("SmartphonExpress.Remove-OneDrive.ps1")
                ?? throw new InvalidOperationException("Risorsa Remove-OneDrive.ps1 non trovata nell'eseguibile.");
            using (var output = File.Create(scriptPath))
                stream.CopyTo(output);

            Log("ONEDRIVE: script incorporato estratto in " + scriptPath);
            Log("ONEDRIVE: avvio procedura interattiva...");

            Process.Start(new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -File \"{scriptPath}\"",
                UseShellExecute = true,
                WorkingDirectory = baseDir
            });
        }
        catch (Exception ex)
        {
            Log("ONEDRIVE: ERRORE - " + ex.Message);
            MessageBox.Show(owner,
                "Impossibile avviare la rimozione di OneDrive.\n\n" + ex.Message,
                title,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

}

