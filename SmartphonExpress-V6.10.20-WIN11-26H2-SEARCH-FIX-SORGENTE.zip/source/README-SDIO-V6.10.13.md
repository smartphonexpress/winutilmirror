# SDIO avvio rapido V6.10.13

Confronto archivi: solo V6.10.11 e V6.10.12 contengono Driver Sniffer / SDIO. La V6.10.12 usa OpenFileDialog a ogni avvio.

Modifica: ricerca in cartelle Tools/SDIO e SDIO adiacenti al programma, oppure percorso persistente in LocalAppData/SmartphonExpress/DriverTools/sdio-path.txt. Al primo avvio si seleziona una volta sola, poi avvio diretto. Pulsante Cambia cartella SDIO.

**Limite**: non è implementato download automatico: nessun URL/versione/checksum ufficiale verificato per un pacchetto redistribuibile. Non scaricare/eseguire binari da link non verificati.

Non compilato o testato su Windows. La selezione persistente va verificata con avvii ripetuti e spostamento/rimozione dell'eseguibile.
