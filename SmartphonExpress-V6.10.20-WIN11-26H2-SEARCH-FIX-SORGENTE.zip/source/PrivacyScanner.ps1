﻿# SmartphonExpress Privacy Scanner v1.3 - Windows PowerShell 5.1 / Outlook classico
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$ErrorActionPreference = 'Stop'
if(([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){[void][Windows.Forms.MessageBox]::Show('Avviare Privacy Scanner senza privilegi di amministratore, come Outlook.');return}
$script:rows = @{}
$script:cancel = $false
$script:busy = $false
$script:count = 0
$script:errors = 0
$script:newCount = 0
$script:stores = @{}
$script:seen = @{}
$script:history = @{}
$script:whitelist = @{}
$script:stateDir = Join-Path $env:LOCALAPPDATA 'SmartphonExpress\PrivacyScanner\State'
[void][IO.Directory]::CreateDirectory($script:stateDir)
Add-Type -AssemblyName System.Security
$script:mutex=[Threading.Mutex]::new($false,('Local\SPXPrivacy-'+[Security.Principal.WindowsIdentity]::GetCurrent().User.Value))
try{$locked=$script:mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$locked=$true}
if(!$locked){[void][Windows.Forms.MessageBox]::Show('Privacy Scanner gia aperto.');$script:mutex.Dispose();return}
function Read-State($name){
 $path=Join-Path $script:stateDir $name
 if(!(Test-Path -LiteralPath $path)){return $null}
 $bytes=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($path),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
 return [System.Management.Automation.PSSerializer]::Deserialize([Text.Encoding]::UTF8.GetString($bytes))
}
function Write-State($name,$value){
 $path=Join-Path $script:stateDir $name;$tmp=$path+'.tmp'
 $xml=[System.Management.Automation.PSSerializer]::Serialize($value,8)
 $encrypted=[Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($xml),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
 [IO.File]::WriteAllBytes($tmp,$encrypted)
 if([IO.File]::Exists($path)){[IO.File]::Replace($tmp,$path,$null)}else{[IO.File]::Move($tmp,$path)}
}
function Save-Preferences {Write-State 'preferences.dat' @{History=$script:history;Whitelist=$script:whitelist}}
try{$prefs=Read-State 'preferences.dat';if($prefs){$script:history=$prefs.History;$script:whitelist=$prefs.Whitelist}}catch{[void][Windows.Forms.MessageBox]::Show('Storico/lista bianca non leggibili. Per sicurezza le disiscrizioni sono disabilitate in questa sessione.');$script:stateFailed=$true}
function Sender-Key($r){return ($r.Casella+'|'+$r.Mittente).ToLowerInvariant()}
function Update-RowState($r,$key){
 $r.Protezione='';$r.Recidiva='';$r.Esito='Da elaborare'
 if($script:whitelist.ContainsKey((Sender-Key $r))){$r.Protezione='Lista bianca';$r.Scelta=$false}
 if($script:history.ContainsKey($key)){$h=$script:history[$key];$r.Esito=$h.Esito;$r.Scelta=$false;if($h.Esito -in @('Richiesta affidata a Outlook','Richiesta HTTP accettata') -and $r.Ultima -gt ([datetime]$h.Data).AddDays(14)){$r.Recidiva='Nuova mail dopo 14 giorni'}}
}
function Update-AllStates {foreach($k in $script:rows.Keys){Update-RowState $script:rows[$k] $k}}

$defaultTargets = @('orgio@hotmail.it','giorgio.piccoli@live.it','info@smartphonexpress.it')
$form = New-Object Windows.Forms.Form
$form.Text = 'SmartphonExpress Privacy Scanner 1.3'
$form.Size = New-Object Drawing.Size(1200,720)
$form.MinimumSize = New-Object Drawing.Size(850,500)
$form.StartPosition = 'CenterScreen'
$top = New-Object Windows.Forms.FlowLayoutPanel
$top.Dock = 'Top'; $top.Height = 170; $top.Padding = New-Object Windows.Forms.Padding(8); $top.WrapContents = $true
$form.Controls.Add($top)
function Add-Button($label) { $b = New-Object Windows.Forms.Button; $b.Text=$label; $b.AutoSize=$true; $b.Height=32; $top.Controls.Add($b); return $b }
$period = New-Object Windows.Forms.ComboBox
$period.DropDownStyle='DropDownList'; $period.Width=150
[void]$period.Items.Add('Ultimi 12 mesi'); [void]$period.Items.Add('Tutto lo storico'); $period.SelectedIndex=0; $top.Controls.Add($period)
$scope = New-Object Windows.Forms.ComboBox
$scope.DropDownStyle='DropDownList'; $scope.Width=185
[void]$scope.Items.Add('3 caselle originali'); [void]$scope.Items.Add('Tutte le 6 caselle'); $scope.SelectedIndex=0; $top.Controls.Add($scope)
$start=Add-Button 'Scansiona'; $stop=Add-Button 'Interrompi'; $stop.Enabled=$false
$csv=Add-Button 'Esporta CSV'; $excel=Add-Button 'Esporta Excel'; $copy=Add-Button 'Copia link'; $gdpr=Add-Button 'Bozza GDPR'; $revoca=Add-Button 'Bozza revoca marketing'; $selectAll=Add-Button 'Spunta newsletter visibili'; $clearAll=Add-Button 'Deseleziona'; $unsubscribe=Add-Button 'Disiscrivi spuntate'; $review=Add-Button 'Apri link assistito'
$incremental=New-Object Windows.Forms.CheckBox;$incremental.Text='Incrementale (periodo iniziale)';$incremental.AutoSize=$true;$top.Controls.Add($incremental)
$white=Add-Button 'Proteggi spuntate';$unwhite=Add-Button 'Rimuovi protezione';$hist=Add-Button 'Storico richieste';$rec=Add-Button 'Solo recidivi';$resetFilter=Add-Button 'Tutti i risultati';$block=Add-Button 'Blocco assistito Outlook';$public=Add-Button 'Ricerca web casella';$forget=Add-Button 'Elimina cache locale'
$script:onlyRec=$false
$filter=New-Object Windows.Forms.TextBox; $filter.Width=190; $top.Controls.Add($filter)
$cat=New-Object Windows.Forms.ComboBox; $cat.DropDownStyle='DropDownList'; $cat.Width=145; [void]$cat.Items.AddRange(@('Tutte','Newsletter','Registrazione','Acquisti e spedizioni','Servizi','Sospetto','Altro')); $cat.SelectedIndex=0; $top.Controls.Add($cat)
$status=New-Object Windows.Forms.Label; $status.Dock='Bottom'; $status.Height=30; $status.Text='Pronto. Il campo di testo filtra i risultati.'; $form.Controls.Add($status)
$grid=New-Object Windows.Forms.DataGridView; $grid.Dock='Fill'; $grid.ReadOnly=$false; $grid.AllowUserToAddRows=$false; $grid.SelectionMode='FullRowSelect'; $grid.MultiSelect=$true; $grid.AutoSizeColumnsMode='DisplayedCells'; $grid.RowHeadersVisible=$false
$form.Controls.Add($grid); $grid.BringToFront()
$columns=@('Casella','Dominio','Categoria','Mittente','Messaggi','Ultima','Oggetto','Disiscrizione')
$check=New-Object Windows.Forms.DataGridViewCheckBoxColumn; $check.Name='Scelta'; $check.HeaderText='Spunta'; [void]$grid.Columns.Add($check)
$columns += @('Esito','Protezione','Recidiva')
foreach($c in $columns){[void]$grid.Columns.Add($c,$c);$grid.Columns[$c].ReadOnly=$true};$grid.Columns['Esito'].DisplayIndex=1
$grid.Add_CurrentCellDirtyStateChanged({if($grid.IsCurrentCellDirty){[void]$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit)}})
$grid.Add_CellValueChanged({param($sender,$e) if($e.RowIndex -ge 0 -and $e.ColumnIndex -eq 0){$gr=$grid.Rows[$e.RowIndex];if($gr.Tag){$gr.Tag.Scelta=[bool]$gr.Cells[0].Value}}})
function Get-VisibleRows { $q=$filter.Text.Trim(); $category=$cat.SelectedItem; @($script:rows.Values | Where-Object { (!$script:onlyRec -or $_.Recidiva) -and ($category -eq 'Tutte' -or $_.Categoria -eq $category) -and (!$q -or (($_.Casella+' '+$_.Dominio+' '+$_.Mittente+' '+$_.Oggetto) -like ('*'+$q+'*'))) } | Sort-Object Ultima -Descending) }
function Refresh-Grid { $grid.Rows.Clear(); foreach($r in (Get-VisibleRows)){ $i=$grid.Rows.Add([object[]]@($r.Scelta,$r.Casella,$r.Dominio,$r.Categoria,$r.Mittente,$r.Messaggi,$r.Ultima.ToString('yyyy-MM-dd HH:mm'),$r.Oggetto,$r.Disiscrizione,$r.Esito,$r.Protezione,$r.Recidiva));$grid.Rows[$i].Tag=$r }; $status.Text="Messaggi analizzati: $script:count | Gruppi: $($script:rows.Count) | Errori di lettura: $script:errors | Nuovi: $script:newCount" }
$filter.Add_TextChanged({if(!$script:busy){Refresh-Grid}}); $cat.Add_SelectedIndexChanged({if(!$script:busy){Refresh-Grid}})
function Release-Com($o){ if($null -ne $o -and [Runtime.InteropServices.Marshal]::IsComObject($o)){try{[void][Runtime.InteropServices.Marshal]::ReleaseComObject($o)}catch{}} }
function Get-Header($m){$p=$null;try{$p=$m.PropertyAccessor; return [string]$p.GetProperty('http://schemas.microsoft.com/mapi/proptag/0x007D001E')}catch{return ''}finally{Release-Com $p}}
function Read-Mail($m,$account,$junk){
 if($m.Class -ne 43){return}
 $entry=[string]$m.EntryID
 $messageKey=$account+'|'+$entry
 if($entry -and $script:seen.ContainsKey($messageKey)){return}
 $date=[datetime]$m.ReceivedTime
 if($date -lt $script:since){return}
 $sender=[string]$m.SenderEmailAddress; $subject=[string]$m.Subject
 if($m.SenderEmailType -eq 'EX'){ $p=$null;try{$p=$m.PropertyAccessor;$sender=[string]$p.GetProperty('http://schemas.microsoft.com/mapi/proptag/0x5D01001F')}catch{}finally{Release-Com $p}}
 $domain='sconosciuto'; if($sender -match '@([^@\s>]+)$'){$domain=$Matches[1].ToLowerInvariant()}
 $header=Get-Header $m; $link=''; $oneClick=$false; $headerLink=$false; $listId=''; if($header -match '(?im)^List-Id:[ \t]*([^\r\n]+)'){$listId=$Matches[1].Trim()}; $list=$header -match '(?im)^List-(Unsubscribe|Id):'
 if($header -match '(?im)^List-Unsubscribe:\s*([^\r\n]*(?:\r?\n[ \t]+[^\r\n]*)*)'){ $value=$Matches[1]; if($value -match '<(https?://[^>]+)>'){$link=$Matches[1]}elseif($value -match '<(mailto:[^>]+)>'){$link=$Matches[1]} }
 $headerLink=[bool]$link; $oneClick=$headerLink -and ($header -match '(?im)^List-Unsubscribe-Post:[ \t]*List-Unsubscribe=One-Click[ \t]*\r?$');
 $body=''; try{$body=[string]$m.Body;if($body.Length -gt 24000){$body=$body.Substring(0,24000)}}catch{}
 $registration=$subject -match '(?i)benvenut|welcome|registrazion|verifica.*(email|account)|verify.*(email|account)|confirm.*(account|registration)|attiva.*account|activate.*account|account creat|conferma.*iscrizione'
 $newsletter=$list -or (($subject+' '+$body) -match '(?i)unsubscribe|annulla iscrizione|disiscriv|cancell[ai].{0,15}iscrizione|newsletter|gestisci.{0,20}preferenze')
 $category='Altro'; if($junk -or ($subject -match '(?i)account.{0,25}(sospeso|bloccato|suspended)|accesso temporaneamente limitato|azione richiesta sul tuo account') -or $domain -eq 'sconosciuto'){$category='Sospetto'}elseif($registration){$category='Registrazione'}elseif($subject -match '(?i)spedizion|shipment|on demand delivery|tracking|consegn|order confirmation|conferma ordine|fattura|invoice|ricevuta|receipt'){$category='Acquisti e spedizioni'}elseif($subject -match '(?i)password|codice di sicurezza|security code|accesso|login|termini e condizioni|rinnovo|scad[eo]'){$category='Servizi'}elseif($newsletter){$category='Newsletter'}
 if(!$link -and $newsletter){try{$html=[string]$m.HTMLBody; if($html.Length -gt 500000){$html=$html.Substring(0,500000)}; foreach($a in [regex]::Matches($html,'(?is)<a\b[^>]*href\s*=\s*["'']([^"'']+)["''][^>]*>(.*?)</a>')){if($a.Groups[2].Value -match '(?i)unsubscribe|disiscriv|annulla iscrizione|cancella iscrizione'){ $candidate=[System.Net.WebUtility]::HtmlDecode($a.Groups[1].Value); if($candidate -match '^(https?://|mailto:)'){$link=$candidate;break}}}}catch{}}
 $key=$account+'|'+$sender+'|'+$category+'|'+$listId
 if(!$script:rows.ContainsKey($key)){$script:rows[$key]=[pscustomobject]@{Casella=$account;Dominio=$domain;Categoria=$category;Mittente=$sender;Messaggi=0;Ultima=$date;Oggetto=$subject;Disiscrizione=$link;OneClick=$oneClick;HeaderLink=$headerLink;Scelta=$false;Esito='Da elaborare';Protezione='';Recidiva='';Key=$key}}
 $r=$script:rows[$key];$r.Messaggi++;if($date -ge $r.Ultima){$r.Ultima=$date;$r.Oggetto=$subject;$r.Mittente=$sender;if($link){$r.Disiscrizione=$link;$r.OneClick=$oneClick;$r.HeaderLink=$headerLink}}elseif(!$r.Disiscrizione -and $link){$r.Disiscrizione=$link;$r.OneClick=$oneClick;$r.HeaderLink=$headerLink}
 if($entry){$script:seen[$messageKey]=$true}
 $script:count++;$script:newCount++
}
function Scan-Folder($folder,$account,$junk){
 if($script:cancel){return}; $items=$null;$children=$null
 try{
 $isjunk=$junk -or ([string]$folder.Name -match '(?i)posta indesiderata|junk|spam')
 if($folder.DefaultItemType -eq 0){$items=$folder.Items; $n=$items.Count; for($i=1;$i -le $n;$i++){if($script:cancel){break};$m=$null;try{$m=$items.Item($i);Read-Mail $m $account $isjunk}catch{$script:errors++}finally{Release-Com $m};if($i%20 -eq 0){$status.Text="Scansione: $account / $($folder.Name) | $script:count messaggi";[Windows.Forms.Application]::DoEvents()}}}
 }catch{$script:errors++}finally{Release-Com $items}
 try{$children=$folder.Folders;for($j=1;$j -le $children.Count;$j++){if($script:cancel){break};$child=$null;try{$child=$children.Item($j);Scan-Folder $child $account $isjunk}catch{$script:errors++}finally{Release-Com $child}}}catch{$script:errors++}finally{Release-Com $children}
}
$start.Add_Click({
 $script:busy=$true;$script:cancel=$false;$script:count=0;$script:errors=0;$script:newCount=0;$script:seen=@{};$script:rows=@{};$grid.Rows.Clear();$start.Enabled=$false;$stop.Enabled=$true
 $script:since=[datetime]::MinValue;if($period.SelectedIndex -eq 0){$script:since=(Get-Date).AddMonths(-12)}
 $cacheName='scan-'+$scope.SelectedIndex+'-'+$period.SelectedIndex+'.dat'
 if($incremental.Checked){try{$cache=Read-State $cacheName;if($cache){$script:rows=$cache.Rows;$script:seen=$cache.Seen;foreach($cachedRow in $script:rows.Values){$cachedRow.Scelta=$false};$script:count=[int]$cache.Count;$script:since=[datetime]$cache.Since}}catch{[void][Windows.Forms.MessageBox]::Show('Cache non leggibile: scansione completa.');$script:rows=@{};$script:seen=@{};$script:count=0}}
 $targets=@($defaultTargets)
 if($scope.SelectedIndex -eq 1){$targets+=@('amministrazione@smartphonexpress.it','giorgio.piccoli@smartphonexpress.it','orgio.giorgio@gmail.com')}
 $app=$null;$ns=$null;$accounts=$null;$stores=$null;$matched=@();$scanned=@{}
 try{
 try{$app=[System.Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application')}catch{
  throw ('Impossibile collegarsi a Outlook gia aperto. Aprire Outlook classico e avviare lo scanner con gli stessi privilegi (normalmente senza amministratore). Dettaglio: '+$_.Exception.Message)
 }
 $ns=$app.GetNamespace('MAPI');$accounts=$ns.Accounts
 for($a=1;$a -le $accounts.Count;$a++){ $acc=$null;$store=$null;$root=$null;try{$acc=$accounts.Item($a);$address=[string]$acc.SmtpAddress;if($targets -contains $address){$store=$acc.DeliveryStore;if($null -ne $store){$id=[string]$store.StoreID;if(!$scanned.ContainsKey($id)){$scanned[$id]=$true;$matched+=$address;$root=$store.GetRootFolder();Scan-Folder $root $address $false}}}}catch{$script:errors++}finally{Release-Com $root;Release-Com $store;Release-Com $acc};if($script:cancel){break}}
 if(!$script:cancel){$stores=$ns.Stores;for($s=1;$s -le $stores.Count;$s++){ $store=$null;$root=$null;try{$store=$stores.Item($s);$id=[string]$store.StoreID;$name=[string]$store.DisplayName;if(!$scanned.ContainsKey($id)){foreach($t in $targets){if($name -like ('*'+$t+'*')){$scanned[$id]=$true;$matched+=$t;$root=$store.GetRootFolder();Scan-Folder $root $t $false;break}}}}catch{$script:errors++}finally{Release-Com $root;Release-Com $store};if($script:cancel){break}}}
 $missing=@($targets|Where-Object{$_ -notin $matched});if($missing.Count -gt 0 -and !$script:cancel){[void][Windows.Forms.MessageBox]::Show(('Caselle non identificate o con archivio condiviso: '+($missing -join ', ')+'. Verifica il profilo Outlook.'))}
 }catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Errore Outlook')}finally{Release-Com $stores;Release-Com $accounts;Release-Com $ns;Release-Com $app;$script:busy=$false;$start.Enabled=$true;$stop.Enabled=$false;Update-AllStates;try{if($script:rows.Count){Write-State $cacheName @{Rows=$script:rows;Seen=$script:seen;Count=$script:count;Since=$script:since}}}catch{[void][Windows.Forms.MessageBox]::Show('Impossibile salvare cache: '+$_.Exception.Message)};Refresh-Grid;if($script:cancel){$status.Text+=' | Scansione interrotta'}}
})
$stop.Add_Click({$script:cancel=$true})
$form.Add_FormClosing({param($sender,$e) if($script:busy){$script:cancel=$true;$e.Cancel=$true}})
function Safe-Cell($v){$s=[string]$v;if($s -match '^\s*[=+@-]') {return "'$s"};return $s}
function Export-Report($xlsx){
 if($script:busy){return};$data=@(Get-VisibleRows);if(!$data.Count){return};$dialog=New-Object Windows.Forms.SaveFileDialog
 if($xlsx){$dialog.Filter='Excel (*.xlsx)|*.xlsx';$dialog.FileName='SPX-Privacy.xlsx'}else{$dialog.Filter='CSV (*.csv)|*.csv';$dialog.FileName='SPX-Privacy.csv'}
 if($dialog.ShowDialog() -ne 'OK'){return}
 try{if(!$xlsx){$data|ForEach-Object{$r=$_;$o=[ordered]@{};foreach($c in $columns){$o[$c]=Safe-Cell $r.$c};[pscustomobject]$o}|Export-Csv -LiteralPath $dialog.FileName -Delimiter ';' -NoTypeInformation -Encoding UTF8}else{
 $xl=$null;$book=$null;$sheet=$null;$books=$null;$sheets=$null;$range=$null
 try{$xl=New-Object -ComObject Excel.Application;$xl.DisplayAlerts=$false;$books=$xl.Workbooks;$book=$books.Add();$sheets=$book.Worksheets;$sheet=$sheets.Item(1);$matrix=New-Object 'object[,]' ($data.Count+1),$columns.Count;for($j=0;$j -lt $columns.Count;$j++){$matrix[0,$j]=$columns[$j]};for($i=0;$i -lt $data.Count;$i++){for($j=0;$j -lt $columns.Count;$j++){$matrix[($i+1),$j]=Safe-Cell ($data[$i].($columns[$j]))}};$range=$sheet.Range('A1',('K'+($data.Count+1)));$range.NumberFormat='@';$range.Value2=$matrix;$book.SaveAs($dialog.FileName,51);$book.Close($false)}finally{if($xl){try{$xl.Quit()}catch{}};Release-Com $range;Release-Com $sheet;Release-Com $sheets;Release-Com $book;Release-Com $books;Release-Com $xl}
 };[void][Windows.Forms.MessageBox]::Show('Report esportato.')}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message,'Errore esportazione')}finally{$dialog.Dispose()}
}
$csv.Add_Click({Export-Report $false});$excel.Add_Click({Export-Report $true})
$copy.Add_Click({if(!$script:busy -and $grid.SelectedRows.Count){if($grid.SelectedRows[0].Tag.Categoria -eq 'Sospetto'){return};$v=[string]$grid.SelectedRows[0].Cells['Disiscrizione'].Value;if($v){[Windows.Forms.Clipboard]::SetText($v);$status.Text='Link copiato, non aperto. Verifica il dominio prima di utilizzarlo.'}}})
function Open-PrivacyDraft($erase){
 if($script:busy -or !$grid.SelectedRows.Count){return};$r=$grid.SelectedRows[0].Tag;if(!$r -or $r.Categoria -eq 'Sospetto'){return}
 $address=$r.Casella;$domain=$r.Dominio;$subject='Opposizione al marketing diretto - art. 21 GDPR'
 $body="Spett.le titolare del trattamento ($domain),`r`nmi oppongo al trattamento per marketing diretto associato all'indirizzo $address ai sensi dell'art. 21 GDPR e revoco ogni eventuale consenso al marketing. Chiedo conferma dell'avvenuta cessazione delle comunicazioni promozionali.`r`nCordiali saluti."
 if($erase){$subject='Richiesta cancellazione dati personali - art. 17 GDPR';$body="Spett.le titolare del trattamento ($domain),`r`nchiedo la cancellazione dei dati personali associati all'indirizzo $address ai sensi dell'art. 17 GDPR, ove applicabile, e mi oppongo al marketing diretto ai sensi dell'art. 21 GDPR. Chiedo conferma del riscontro e delle eventuali ragioni di conservazione obbligatoria.`r`nCordiali saluti."}
 if([Windows.Forms.MessageBox]::Show('Aprire una bozza Outlook senza destinatario? Inserire manualmente il recapito privacy ufficiale. Nessun invio automatico.','Bozza privacy','YesNo','Question','Button2') -ne 'Yes'){return}
 $app=$null;$ns=$null;$accounts=$null;$acc=$null;$mail=$null
 try{$app=[Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application');$ns=$app.GetNamespace('MAPI');$accounts=$ns.Accounts;for($i=1;$i -le $accounts.Count;$i++){$a=$accounts.Item($i);if([string]$a.SmtpAddress -eq $address){$acc=$a;break};Release-Com $a};if(!$acc){throw 'Account di invio non trovato.'};$mail=$app.CreateItem(0);$mail.SendUsingAccount=$acc;if([string]$mail.SendUsingAccount.SmtpAddress -ne $address){throw 'Account di invio non verificato.'};$mail.Subject=$subject;$mail.Body=$body;$mail.Display($false)}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}finally{Release-Com $mail;Release-Com $acc;Release-Com $accounts;Release-Com $ns;Release-Com $app}
}
$gdpr.Add_Click({Open-PrivacyDraft $true});$revoca.Add_Click({Open-PrivacyDraft $false})

$selectAll.Add_Click({if(!$script:busy){foreach($gr in $grid.Rows){if($gr.Tag.Categoria -eq 'Newsletter' -and !$gr.Tag.Protezione -and $gr.Tag.Esito -eq 'Da elaborare'){$gr.Cells[0].Value=$true}}}})
$clearAll.Add_Click({if(!$script:busy){foreach($r in $script:rows.Values){$r.Scelta=$false};Refresh-Grid}})
function Get-SafeUri($r){
 $u=$null
 if(![uri]::TryCreate([string]$r.Disiscrizione,[UriKind]::Absolute,[ref]$u)){return $null}
 if($u.Scheme -ne 'https' -or !$u.IsDefaultPort -or $u.UserInfo -or $u.HostNameType -ne [UriHostNameType]::Dns){return $null}
 # Automatic requests only to the exact sender domain or its subdomain.
 if($u.IdnHost -ne $r.Dominio -and !$u.IdnHost.EndsWith('.'+$r.Dominio,[StringComparison]::OrdinalIgnoreCase)){return $null}
 if($u.IdnHost -notmatch '\.' -or $u.IdnHost -match '\.(local|internal|localhost|test|invalid)$'){return $null}
 return $u
}
function Test-PublicIPv4($hostName){
 $ips=@([Net.Dns]::GetHostAddresses($hostName));if(!$ips.Count){return $false}
 foreach($ip in $ips){if($ip.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork){return $false};$b=$ip.GetAddressBytes();if($b[0] -in @(0,10,127) -or $b[0] -ge 224 -or ($b[0] -eq 169 -and $b[1] -eq 254) -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or ($b[0] -eq 192 -and $b[1] -in @(0,168)) -or ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) -or ($b[0] -eq 198 -and $b[1] -in @(18,19))){return $false}}
 return $true
}
function Get-MailTarget($r){
 if(!$r.HeaderLink -or $r.Disiscrizione -notmatch '^mailto:([^?]+)(?:\?([^#]*))?$'){return $null}
 $query=$Matches[2];$to=[uri]::UnescapeDataString($Matches[1]);$sub='Unsubscribe';$body='Please unsubscribe this email address from your mailing list.'
 if($to -notmatch '^[a-zA-Z0-9._+\-=]+@([a-zA-Z0-9.-]+)$' -or $Matches[1] -ne $r.Dominio){return $null}
 foreach($part in ($query -split '&')){if($part -match '^(subject|body)=(.*)$'){$k=$Matches[1];$v=[uri]::UnescapeDataString($Matches[2]);if($v -match '[\x00-\x1f]' -or $v.Length -gt 1000){return $null};if($k -eq 'subject'){$sub=$v}else{$body=$v}}elseif($part){return $null}}
 return [pscustomobject]@{To=$to;Subject=$sub;Body=$body}
}
function Send-Unsubscribe($r,$target){
 $app=$null;$ns=$null;$accounts=$null;$acc=$null;$mail=$null
 try{$app=[Runtime.InteropServices.Marshal]::GetActiveObject('Outlook.Application');$ns=$app.GetNamespace('MAPI');$accounts=$ns.Accounts
 for($i=1;$i -le $accounts.Count;$i++){$a=$accounts.Item($i);if([string]$a.SmtpAddress -eq $r.Casella){$acc=$a;break};Release-Com $a}
 if(!$acc){throw 'Account di invio non trovato: nessun invio.'}
 $mail=$app.CreateItem(0);$mail.SendUsingAccount=$acc;if([string]$mail.SendUsingAccount.SmtpAddress -ne $r.Casella){throw 'Account non verificato.'};$mail.To=$target.To;$mail.Subject=$target.Subject;$mail.Body=$target.Body;$mail.Send()
 }finally{Release-Com $mail;Release-Com $acc;Release-Com $accounts;Release-Com $ns;Release-Com $app}
}
$unsubscribe.Add_Click({
 if($script:busy -or $script:stateFailed){return};[void]$grid.EndEdit();$chosen=@($script:rows.Values|Where-Object{$_.Scelta -and !$_.Protezione -and $_.Esito -eq 'Da elaborare'});if(!$chosen.Count){return}
 $plan=@(foreach($r in $chosen){$method='Manuale';$target=$null;if($r.Categoria -eq 'Newsletter' -and $r.HeaderLink){$target=Get-MailTarget $r;if($target){$method='Email'}elseif($r.OneClick -and (Get-SafeUri $r)){$method='OneClick'}};[pscustomobject]@{Row=$r;Method=$method;Target=$target}})
 $auto=@($plan|Where-Object{$_.Method -ne 'Manuale'});$preview=($auto|ForEach-Object{if($_.Method -eq 'Email'){"$($_.Row.Casella) -> $($_.Target.To) [email]"}else{"$($_.Row.Casella) -> $($_.Row.Dominio) [HTTPS POST]"}}) -join "`r`n"
 $confirm=New-Object Windows.Forms.Form;$confirm.Text='Conferma disiscrizioni';$confirm.Size=New-Object Drawing.Size(720,500);$confirm.StartPosition='CenterParent'
 $txt=New-Object Windows.Forms.TextBox;$txt.Multiline=$true;$txt.ReadOnly=$true;$txt.ScrollBars='Both';$txt.Dock='Fill';$txt.Text="Richieste automatiche: $($auto.Count). Manuali/protette: $($chosen.Count-$auto.Count).`r`nI server riceveranno la richiesta; Outlook inviera le email indicate. Nessuna email verra cancellata.`r`n`r`n$preview";$confirm.Controls.Add($txt)
 $ok=New-Object Windows.Forms.Button;$ok.Text='Conferma e procedi';$ok.Dock='Bottom';$ok.Height=42;$ok.DialogResult='Yes';$confirm.Controls.Add($ok);
 $answer=$confirm.ShowDialog($form);$confirm.Dispose();if($answer -ne 'Yes'){return}
 $script:busy=$true;$script:cancel=$false;$start.Enabled=$false;$stop.Enabled=$true
 try{foreach($p in $plan){if($script:cancel){break};$r=$p.Row;try{
 if($p.Method -ne 'Manuale'){$script:history[$r.Key]=@{Casella=$r.Casella;Mittente=$r.Mittente;Data=(Get-Date);Esito='Tentativo in corso / da verificare'};try{Save-Preferences}catch{$script:stateFailed=$true;$script:cancel=$true;throw}}
 if($p.Method -eq 'Email'){Send-Unsubscribe $r $p.Target;$r.Esito='Richiesta affidata a Outlook'}
 elseif($p.Method -eq 'OneClick'){$u=Get-SafeUri $r;if(!(Test-PublicIPv4 $u.IdnHost)){throw 'Indirizzo non verificato: usare metodo assistito.'};$resp=Invoke-WebRequest -Uri $u -Method Post -Body 'List-Unsubscribe=One-Click' -ContentType 'application/x-www-form-urlencoded' -UseBasicParsing -MaximumRedirection 0 -TimeoutSec 15 -ErrorAction Stop;if([int]$resp.StatusCode -ge 200 -and [int]$resp.StatusCode -lt 300){$r.Esito='Richiesta HTTP accettata'}else{throw 'Risposta non riuscita'}}
 else{$r.Esito='Intervento manuale necessario'}
 }catch{$r.Esito='Non verificata / errore: controllare manualmente'};if($p.Method -ne "Manuale"){$script:history[$r.Key]=@{Casella=$r.Casella;Mittente=$r.Mittente;Data=(Get-Date);Esito=$r.Esito};try{Save-Preferences}catch{$script:stateFailed=$true;$script:cancel=$true;[void][Windows.Forms.MessageBox]::Show("Salvataggio storico fallito. Elaborazione interrotta; verificare le richieste gia effettuate.")}};$r.Scelta=$false;$status.Text="Elaborazione: $($r.Dominio) - $($r.Esito)";[Windows.Forms.Application]::DoEvents()}}
 finally{$script:busy=$false;$start.Enabled=$true;$stop.Enabled=$false;Refresh-Grid}
})
$review.Add_Click({if($script:busy -or !$grid.SelectedRows.Count){return};$r=$grid.SelectedRows[0].Tag;if(!$r -or $r.Categoria -eq 'Sospetto'){return};$u=Get-SafeUri $r;if(!$u){[void][Windows.Forms.MessageBox]::Show('Link non verificabile o dominio diverso. Cerca il sito ufficiale autonomamente.');return};if([Windows.Forms.MessageBox]::Show("Aprire nel browser?`r`n$($u.IdnHost)`r`nVerifica che il dominio sia attendibile.",'Conferma','YesNo','Warning','Button2') -eq 'Yes'){Start-Process $u.AbsoluteUri}})
function Get-ChosenRows { [void]$grid.EndEdit();return @($script:rows.Values|Where-Object{$_.Scelta}) }
$white.Add_Click({if($script:busy -or $script:stateFailed){return};foreach($r in (Get-ChosenRows)){$script:whitelist[(Sender-Key $r)]=$true};try{Save-Preferences;Update-AllStates;Refresh-Grid}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}})
$unwhite.Add_Click({if($script:busy -or $script:stateFailed){return};foreach($r in (Get-ChosenRows)){[void]$script:whitelist.Remove((Sender-Key $r))};try{Save-Preferences;Update-AllStates;Refresh-Grid}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}})
$hist.Add_Click({if($script:busy){return};$h=@($script:history.Values|Sort-Object Data -Descending|ForEach-Object{[pscustomobject]$_});if(!$h.Count){[void][Windows.Forms.MessageBox]::Show('Nessuna richiesta nello storico.');return};$h|Out-GridView -Title 'Storico disiscrizioni - richieste, non conferme definitive'})
$rec.Add_Click({if(!$script:busy){$script:onlyRec=$true;Refresh-Grid}})
$resetFilter.Add_Click({if(!$script:busy){$script:onlyRec=$false;$cat.SelectedIndex=0;$filter.Clear();Refresh-Grid}})
$block.Add_Click({if($script:busy -or !$grid.SelectedRows.Count){return};$r=$grid.SelectedRows[0].Tag;if(!$r -or $r.Protezione){return};if($r.Mittente -notmatch '^[^@\s]+@[^@\s]+$'){return};[Windows.Forms.Clipboard]::SetText($r.Mittente);[void][Windows.Forms.MessageBox]::Show("Mittente copiato: $($r.Mittente)`r`nCasella: $($r.Casella)`r`nIn Outlook seleziona una mail di quel mittente, Home > Posta indesiderata > Blocca mittente. Verifica la casella attiva. Nessuna regola creata automaticamente.",'Blocco assistito')})
$public.Add_Click({if($script:busy -or !$grid.SelectedRows.Count){return};$r=$grid.SelectedRows[0].Tag;if(!$r){return};$address=[string]$r.Casella;if([Windows.Forms.MessageBox]::Show("Inviare l'indirizzo $address a Google per cercare corrispondenze pubbliche? Nessun messaggio o link privato verra trasmesso.",'Ricerca pubblica','YesNo','Warning','Button2') -eq 'Yes'){Start-Process ('https://www.google.com/search?q='+[uri]::EscapeDataString('"'+$address+'"'))}})
$forget.Add_Click({if($script:busy){return};if([Windows.Forms.MessageBox]::Show('Eliminare i risultati e gli identificativi delle scansioni salvate? Storico richieste e lista bianca saranno conservati.','Cache','YesNo','Question','Button2') -eq 'Yes'){try{Get-ChildItem -LiteralPath $script:stateDir -Filter 'scan-*.dat*' -File|Remove-Item -Force;$script:rows=@{};$script:seen=@{};$script:count=0;$script:newCount=0;Refresh-Grid}catch{[void][Windows.Forms.MessageBox]::Show($_.Exception.Message)}}})
try{[void]$form.ShowDialog()}finally{$form.Dispose();$script:mutex.ReleaseMutex();$script:mutex.Dispose()}

