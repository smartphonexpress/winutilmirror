V6.10.20 - WINDOWS SEARCH FIX
Base: V6.10.19 OFFICE DOWNLOAD FIX.
Aggiornata la voce esistente Ripara Windows Search / Cerca (anche 26H2).
Riavvio effettivo WSearch, registrazione dinamica Search/CBS, reset CBS opzionale con conferma, log build e errori, timeout 300 s.
Nessuna modifica ai preset, a Office, alle policy WebView2 o al database di indicizzazione.
Eseguire con lo stesso account Windows che manifesta il problema.
Compilare con BUILD-EXE.cmd. Test Windows e compilazione non eseguiti in questo ambiente.
