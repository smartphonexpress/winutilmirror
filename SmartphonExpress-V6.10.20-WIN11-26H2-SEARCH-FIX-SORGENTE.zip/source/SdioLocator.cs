using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace SmartphonExpressWindowsTool;

internal static class SdioLocator
{
    private static string SettingsDirectory => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SmartphonExpress", "DriverTools");
    private static string SettingsFile => Path.Combine(SettingsDirectory, "sdio-path.txt");

    internal static bool IsValidCandidate(string? path)
    {
        if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return false;
        return Regex.IsMatch(Path.GetFileName(path), @"^SDIO(?:_[A-Za-z0-9_-]+)?\.exe$", RegexOptions.IgnoreCase);
    }

    internal static void Remember(string path)
    {
        string fullPath = Path.GetFullPath(path);
        if (!IsValidCandidate(fullPath)) throw new InvalidOperationException("File SDIO non valido.");
        Directory.CreateDirectory(SettingsDirectory);
        File.WriteAllText(SettingsFile, fullPath);
    }

    internal static string? FindInstalled()
    {
        try
        {
            if (File.Exists(SettingsFile))
            {
                string saved = File.ReadAllText(SettingsFile).Trim();
                if (IsValidCandidate(saved)) return saved;
            }
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        // Find an existing portable installation without recursively scanning the disk.
        string[] roots = {
            Path.Combine(AppContext.BaseDirectory, "Tools", "SDIO"),
            Path.Combine(AppContext.BaseDirectory, "SDIO"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SmartphonExpress", "Tools", "SDIO")
        };
        foreach (string root in roots)
        {
            try
            {
                if (!Directory.Exists(root)) continue;
                foreach (string name in new[] { "SDIO_x64.exe", "SDIO.exe" })
                {
                    string path = Path.Combine(root, name);
                    if (IsValidCandidate(path)) return path;
                }
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
        return null;
    }
}
