SmartphonExpress Windows Tool V5 - START POLICY

Nuovo metodo START:
- usa la policy ADMX Microsoft "StartPinAppsWhenInstalled";
- scrive gli AppID di Word, Excel, PowerPoint, Outlook, OneNote, Access,
  Publisher, Chrome e Firefox;
- abilita AllowPinnedFolderSettings via WMI Bridge eseguito come SYSTEM;
- elimina il vecchio tentativo PPKG/ICD dalla funzione START.

IMPORTANTE:
StartPinAppsWhenInstalled agisce quando le app vengono installate.
Per una macchina appena formattata, eseguire la voce START PRIMA di installare
Office / Chrome / Firefox, oppure selezionare tutto assicurandosi che START venga
eseguito prima delle installazioni nel flusso desiderato.

AppID usati:
Microsoft.Office.WINWORD.EXE.15
Microsoft.Office.EXCEL.EXE.15
Microsoft.Office.POWERPNT.EXE.15
Microsoft.Office.OUTLOOK.EXE.15
Microsoft.Office.ONENOTE.EXE.15
Microsoft.Office.MSACCESS.EXE.15
Microsoft.Office.MSPUB.EXE.15
Chrome
Firefox
