SmartphonExpress Windows Tool v6.3.0

OFFICE 2024
- Nuova installazione predefinita: Office LTSC Professional Plus 2024
- Include anche Project Professional 2024
- Include anche Visio LTSC Professional 2024
- 64 bit
- Lingua italiana
- Canale ufficiale Microsoft PerpetualVL2024
- Usa Office Deployment Tool e CDN Microsoft
- Rimuove eventuali installazioni Office esistenti prima dell'installazione
- Aggiornamenti abilitati
- NON configura né aggira l'attivazione: è necessaria una licenza valida

MICROSOFT 365
- Rimane disponibile come voce manuale in "Utility, rete e licenze"
- È escluso da "Seleziona tutti"
- Office 2024 e Microsoft 365 sono mutuamente esclusivi:
  selezionando uno viene deselezionato automaticamente l'altro

"Seleziona tutti"
- Seleziona Office 2024 completo
- NON seleziona Microsoft 365
