SMARTPHONEEXPRESS WINDOWS TOOL + OFFICE

Contenuto
- Progetto C# WinForms .NET 8
- Richiesta automatica privilegi amministratore
- Tweak ricostruiti dal log fornito
- Rimozione AppX selezionate nel log
- Log a video
- Ripristino base per le modifiche per cui è definito un valore inverso

COME CREARE L'EXE
1. Installa Microsoft .NET 8 SDK (x64) sul PC Windows.
2. Estrai questa cartella.
3. Esegui BUILD-EXE.cmd.
4. Troverai SmartphonExpressWindowsTool.exe nella cartella indicata a fine compilazione.

IMPORTANTE
Il file originale fornito è un LOG, non il sorgente della Windows Toolbox.
Le operazioni visibili nel log sono state riprodotte direttamente.
Le voci che nel log riportavano soltanto "Running Script" non permettono di sapere
con certezza tutte le istruzioni eseguite dal programma originale: sono state quindi
implementate in modo esplicito e conservativo.

Prima di usare il programma su PC di clienti, provarlo su una macchina di test/VM.
Alcune policy possono avere effetti diversi tra Windows 10/11 e tra edizioni Home/Pro.


VERSIONE + OFFICE
L'ultima voce dell'elenco installa online Microsoft 365 Apps for enterprise:
- 64 bit
- lingua italiana (it-it)
- Current Channel
- aggiornamenti abilitati
- Office Deployment Tool ufficiale Microsoft scaricato al momento dell'installazione

L'installazione non aggira licenze o attivazione: Microsoft 365 dovrà essere attivato
normalmente con un account/licenza valida.
