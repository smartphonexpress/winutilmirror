SmartphonExpress Windows Tool v6.1.1

Aggiunta funzione selezionabile:
  Download SmartphonExpress preconfigurato

Scarica:
  https://raw.githubusercontent.com/smartphonexpress/winutilmirror/main/logo%20ok_vectorized.cmd

Destinazione:
  %USERPROFILE%\Downloads\SmartphonExpress\logo ok_vectorized.cmd

Comportamento:
- scarica il file;
- apre Esplora file con il file selezionato;
- NON esegue il file;
- alla chiusura del tool elimina definitivamente la cartella SmartphonExpress
  e tutto il suo contenuto, senza passare dal Cestino.

Rimane disponibile anche la funzione Download temporaneo (URL manuale).
