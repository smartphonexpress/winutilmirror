SmartphonExpress Windows Tool v6.5.2

FIX BLOCCO NOTE WINDOWS 11

Il vecchio tweak puliva TabState ma non modificava realmente la preferenza interna
dell'app, quindi Notepad poteva continuare a ripristinare schede/sessioni.

La v6.5.2 modifica direttamente l'application hive:
%LOCALAPPDATA%\Packages\Microsoft.WindowsNotepad_8wekyb3d8bbwe\Settings\settings.dat

Impostazioni:
- GhostFile = 0
  -> Start new session / non continuare la sessione precedente
- OpenFile = 1
  -> apri i file in una NUOVA FINESTRA invece che in una nuova scheda

Inoltre, con Notepad chiuso:
- elimina il vecchio LocalState\TabState
- elimina il vecchio LocalState\WindowState

Sicurezza:
- se Notepad è aperto viene tentata solo una chiusura normale
- il processo NON viene terminato forzatamente, per evitare perdita di note non salvate
- se resta aperto, il tweak si interrompe e chiede di chiuderlo manualmente
