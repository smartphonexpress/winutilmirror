SmartphonExpress Windows Tool v6.4.0 — AUDIT WINDOWS 11

Correzioni / miglioramenti applicati

1. Nuovo Outlook
- mantiene HideNewOutlookToggle = 1 (valore corretto per nascondere il toggle)
- DoNewOutlookAutoMigration = 0
- NewOutlookMigrationUserSetting = 0
- NewOutlookAutoMigrationRetryIntervals = 0

2. Privacy / Telemetria
- usa il percorso policy ufficiale:
  HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection
- AllowTelemetry = 0 solo su Enterprise/Education/Server
- AllowTelemetry = 1 su Pro/Home, cioè il minimo effettivamente supportato
- mantiene le altre impostazioni privacy già presenti

3. App in background
- usa la policy ufficiale:
  HKLM\SOFTWARE\Policies\Microsoft\Windows\AppPrivacy
  LetAppsRunInBackground = 2 (Force deny)
- mantiene anche il flag legacy per compatibilità
- Ripristina rimuove entrambi

4. Windows AI / Recall
- DisableAIDataAnalysis applicato sia machine che user
- mantiene TurnOffWindowsCopilot solo come fallback legacy/deprecato
- non forza policy Agent Workspaces non supportate universalmente su Windows Pro stabile

5. Widgets
- aggiunta policy:
  HKLM\SOFTWARE\Policies\Microsoft\Dsh
  AllowNewsAndInterests = 0
- poi rimuove WebExperience come prima

6. Servizi CscService / StorSvc
- rinominati "Servizi avanzati"
- esclusi da "Seleziona tutti"
- restano disponibili manualmente, perché possono avere effetti collaterali

7. Restano invariati e confermati
- Delivery Optimization HTTP only
- Controlled Folder Access
- WPBT
- metadata dispositivi
- menu contestuale classico
- Edge privacy/debloat
- DNS Google / Cloudflare
- Office 2024 / 365
- SmartScreen / Smart App Control

Nota:
Il progetto è stato sottoposto a controllo statico, non compilato in questo ambiente.
