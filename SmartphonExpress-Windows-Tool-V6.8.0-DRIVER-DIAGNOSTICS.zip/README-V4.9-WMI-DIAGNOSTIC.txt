V4.9 - DIAGNOSTICA CSP/WMI START

Questa versione NON tenta più di creare PPKG con ICD.
La voce START interroga direttamente il WMI Bridge Provider:
  root\cimv2\mdm\dmmap

Cerca le classi relative a Start e stampa:
- nome classe;
- proprietà disponibili;
- eventuale proprietà ConfigureStartPins;
- eventuali proprietà Pin / StartLayout.

La prova è intenzionalmente diagnostica: non modifica i pin.
Dopo l'esecuzione, inviare il blocco di log con prefissi:
START/WMI, WMI-CLASS, WMI-PROPS, WMI-PIN-PROPS, WMI-FOUND-CONFIGURESTARTPINS.
