V4.6
Aggiunta voce:
- Blocco note: disattiva ripristino sessione / tab precedenti

IMPORTANTE:
Microsoft espone questa opzione nell'interfaccia del nuovo Blocco note ma non documenta
una chiave Registry/GPO stabile per modificarla automaticamente. Per evitare tweak
fragili, la voce apre Blocco note e indica nel log l'impostazione da scegliere:
'Quando si avvia Blocco note' -> 'Avvia nuova sessione e scarta/ignora le modifiche non salvate'.

Non vengono cancellati automaticamente i file TabState, per evitare perdita di testo non salvato.
