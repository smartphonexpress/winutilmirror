SmartphonExpress Windows Tool v6.1.9

Aggiornamento "Seleziona tutti":
restano ESCLUSE e quindi solo manuali:
- Download temporaneo (URL manuale)
- Crea AppFolder sul Desktop
- Rete: Fix condivisione LAN (Privata + Firewall + Servizi)
- Rete: Fix completo / Share / Diagnostica
- Pulizia: Rimuovi residui KMS / KMSpico / AutoKMS

Il Download SmartphonExpress preconfigurato resta incluso nella selezione totale.

Le voci escluse non vengono modificate dal pulsante "Seleziona tutti":
se le hai spuntate a mano, restano spuntate; se non lo sono, restano non spuntate.
