SmartphonExpress Windows Tool v6.2.0

Nuova funzione manuale:
Windows: disattiva SmartScreen / controlli reputazione app

Applica:
- Microsoft Defender SmartScreen / "Controlla app e file" = disattivato
- SmartScreen Explorer = Off
- "Scegli dove ottenere le app" = Anywhere
- valutazione contenuti/app AppHost = disattivata
- Smart App Control = Off
- richiama CiTool -r quando disponibile

Ripristino:
- rimuove la policy forzata SmartScreen
- SmartScreen Explorer = Warn
- rimuove la forzatura "AicEnabled"
- riattiva EnableWebContentEvaluation
- rimuove la forzatura di Smart App Control
- richiama CiTool -r quando disponibile

La voce è ESCLUSA da "Seleziona tutti" e va scelta manualmente.
Non vengono disattivati Defender Antivirus, Firewall o protezione in tempo reale.

Nota: alcune modifiche possono richiedere il riavvio di Windows.
