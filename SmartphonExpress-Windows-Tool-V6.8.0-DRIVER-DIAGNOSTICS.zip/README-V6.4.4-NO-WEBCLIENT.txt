SmartphonExpress Windows Tool v6.4.4

Pulizia .NET 8:
- rimossi tutti gli usi di System.Net.WebClient
- sostituiti con System.Net.Http.HttpClient
- eliminati i warning SYSLIB0014 legati a WebClient obsoleto
- mantenuto lo stesso comportamento dei download Office Deployment Tool

Obiettivo:
build pulita su .NET 8 senza i 4 warning SYSLIB0014 della v6.4.3.
