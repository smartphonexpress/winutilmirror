SmartphonExpress Windows Tool v6.1.7

Correzioni UI:
- aumentata l'altezza del riquadro opzioni per mostrare tutte le voci di "Ottimizzazione";
- sidebar leggermente più larga;
- area brand ricalibrata per evitare il taglio di "SmartphonExpress".

Correzione Seleziona tutti:
- logica basata sui nomi delle funzioni invece che su indici fragili;
- "Download temporaneo (URL manuale)" resta escluso;
- "Crea AppFolder sul Desktop" resta escluso;
- "Download SmartphonExpress preconfigurato" resta incluso.

Nota:
il progetto non è stato compilato in questo ambiente perché dotnet SDK non è disponibile qui.
