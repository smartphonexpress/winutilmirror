SmartphonExpress Windows Tool v6.1.0

Aggiunta funzione generica selezionabile:
  Download temporaneo (URL manuale)

Flusso:
1. chiede un URL http/https diretto al file;
2. chiede facoltativamente un'estensione da aggiungere;
3. salva il file in:
   %USERPROFILE%\Downloads\SmartphonExpress
4. apre Esplora file con il file selezionato;
5. NON esegue il file;
6. alla chiusura di SmartphonExpress Windows Tool elimina in modo permanente
   l'intera cartella Downloads\SmartphonExpress e il suo contenuto (senza Cestino).

La funzione è volutamente generica: nessun URL o repository è preconfigurato.
