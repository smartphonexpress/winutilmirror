SmartphonExpress Windows Tool v6.5.1

Rifinitura grafica delle icone informative:

- sostituito il simbolo "?" con una "i" dentro un cerchio;
- stile più vicino a Windows 11 / Fluent;
- colore neutro a riposo;
- colore accent al passaggio del mouse;
- nessun effetto pulsante o bordo rettangolare;
- icone meglio allineate verticalmente nelle righe;
- posizionamento leggermente rifinito anche sulle card principali;
- tooltip e click con spiegazione completa invariati.

Nessuna modifica alla logica dei tweak/fix/ottimizzazioni.
