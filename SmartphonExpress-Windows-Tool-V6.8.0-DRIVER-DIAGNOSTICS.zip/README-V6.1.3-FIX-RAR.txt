SmartphonExpress Windows Tool v6.1.3

Correzioni:
- SharpCompress aggiornato a 0.50.4.
- API aggiornata a ArchiveFactory.OpenArchive.
- namespace ExtractionOptions esplicito.
- correzione gestione entry.Key per evitare errore di compilazione.
- download/estrazione RAR invariati.
- pulizia definitiva di archivio, file estratti e cartella SmartphonExpress alla chiusura.
