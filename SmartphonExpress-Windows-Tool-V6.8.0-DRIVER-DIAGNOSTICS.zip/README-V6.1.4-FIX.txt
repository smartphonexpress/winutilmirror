SmartphonExpress Windows Tool v6.1.4

Correzione compilazione RAR:
- chiamata esplicita a SharpCompress.Archives.IArchiveExtensions.WriteToDirectory
- SharpCompress 0.50.4
- invariata la logica di download, estrazione e pulizia alla chiusura.
