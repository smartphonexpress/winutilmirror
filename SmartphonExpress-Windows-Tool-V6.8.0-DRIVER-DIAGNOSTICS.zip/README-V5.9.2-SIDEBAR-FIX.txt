SmartphonExpress Windows Tool v5.9.2

Modifica mirata alla colonna sinistra:
- sidebar più larga;
- logo leggermente più compatto;
- SmartphonExpress non va più a capo/troncato;
- font del brand leggermente ridotto;
- versione aggiornata a 5.9.2 anche nella finestra Info.

Nessuna modifica alle funzioni o al layout principale.
