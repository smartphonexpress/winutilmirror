SmartphonExpress Windows Tool V4.7 - START tramite PPKG

La funzione START non usa più il vecchio tentativo GPO.
Procedura:
1. trova i collegamenti realmente installati di Office, Chrome e Firefox;
2. crea LayoutModification.json;
3. rimuove le vecchie chiavi ConfigureStartPins/ConfigureStartPinsJSON create dalle versioni precedenti;
4. cerca Windows Configuration Designer (ICD.exe);
5. se non presente, prova a installare Windows Configuration Designer dal Microsoft Store tramite winget;
6. genera customizations.xml con Policies/Start/ConfigureStartPins;
7. compila SmartphonExpress-StartPins.ppkg;
8. prova ad applicarlo con Install-ProvisioningPackage;
9. se l'installazione silenziosa fallisce, apre il .ppkg per la conferma manuale di Windows.

Pin richiesti:
Impostazioni, Word, Excel, PowerPoint, Outlook, OneNote, Access, Publisher,
Google Chrome, Mozilla Firefox (le app assenti vengono saltate).

Dopo l'applicazione: disconnettersi e accedere di nuovo.
