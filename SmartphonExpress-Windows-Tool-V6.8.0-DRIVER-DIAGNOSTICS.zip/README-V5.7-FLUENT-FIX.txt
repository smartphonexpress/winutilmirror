SmartphonExpress Windows Tool V5.7 - FLUENT FIX

Correzioni grafiche rispetto alla V5.6:
- finestra avviata massimizzata;
- brand SmartphonExpress non viene più tagliato;
- eliminati i piccoli pannelli con scrollbar orizzontali;
- le 6 operazioni principali sono card vere, semplici e leggibili;
- tutte le altre funzioni sono raccolte in un'unica area scrollabile verticale;
- nessuna scrollbar orizzontale nelle card;
- interfaccia più vicina al mockup Windows 11 approvato;
- tutte le funzioni del programma restano disponibili.
