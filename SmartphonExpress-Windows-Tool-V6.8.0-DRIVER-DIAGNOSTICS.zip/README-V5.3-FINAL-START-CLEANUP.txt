SmartphonExpress Windows Tool V5.3

Correzioni finali al flusso START:
- START spostato PRIMA delle installazioni di Chrome / Firefox / Office;
- quindi StartPinAppsWhenInstalled è già attivo quando le app vengono installate;
- rilevamento Firefox corretto: non seleziona più collegamenti "Navigazione anonima",
  "Private", "Privata" o simili;
- stesso filtro per eventuali scorciatoie Chrome Incognito;
- resta il metodo ConfigureStartPins retroattivo sui Windows 11 24H2 aggiornati
  almeno alla build 26100.4770;
- resta AllowPinnedFolderSettings via WMI/SYSTEM;
- pulizia finale una tantum al riavvio mantenuta;
- controllo licenze corretto mantenuto;
- Accesso controllato alle cartelle mantenuto.

NOTA IMPORTANTE:
Sul PC di test con build 26100.1742, ConfigureStartPins via GPO non è disponibile.
In quel caso il flusso corretto è:
START -> installazione Chrome/Firefox/Office -> disconnessione/riavvio.
