SmartphonExpress Windows Tool v6.1.5

Novità:
- Seleziona tutti: include il download preconfigurato, esclude URL manuale e AppFolder.
- Nuova funzione Crea AppFolder sul Desktop.
- Collegamento a explorer.exe shell:AppsFolder.
- Icona neutra 3x3 senza logo SmartphonExpress.
- Se esiste già, il collegamento viene aggiornato senza duplicati.
