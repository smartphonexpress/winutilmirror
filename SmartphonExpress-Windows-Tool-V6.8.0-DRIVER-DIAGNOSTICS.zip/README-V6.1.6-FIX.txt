SmartphonExpress Windows Tool v6.1.6

Fix:
- corretto il blocco AppFolder che nella v6.1.5 era stato scritto nel Program.cs
  con sequenze letterali \n invece di vere nuove righe;
- mantenuta la logica "Seleziona tutti":
  * download preconfigurato incluso;
  * download URL manuale escluso;
  * AppFolder escluso;
- mantenuta la creazione del collegamento AppFolder sul Desktop con icona neutra.

Nota:
questa correzione elimina la causa degli errori di sintassi concentrati sulla riga 1337.
Il progetto non è stato compilato in questo ambiente perché dotnet SDK non è disponibile qui.
