SmartphonExpress Windows Tool v6.0.0

Modifiche:
- sidebar portata a 270 px sui display stretti e 300 px sui display normali;
- logo leggermente compattato e font SmartphonExpress ridotto: il brand deve essere leggibile per intero;
- versione Info/sidebar dinamica tramite Application.ProductVersion;
- integrati i tre BAT forniti dall'utente come funzioni selezionabili:
  1) Fix condivisione LAN;
  2) Fix rete completo / share / diagnostica;
  3) Pulizia residui KMS/KMSpico/AutoKMS.
- i BAT vengono generati in C:\ProgramData\SmartphonExpress\Scripts e avviati in console visibile,
  così i menu, le password e i pause originali restano utilizzabili.
