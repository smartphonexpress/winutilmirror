SmartphonExpress Windows Tool V6.7.7

- DNS Google/Cloudflare applicati a TUTTE le schede fisiche, anche se scollegate al momento.
- Ripristino DNS automatico applicato a tutte le schede fisiche.
- Diagnostica rete mostra schede fisiche attive e non connesse.
- Schede virtuali/secondarie separate nel report.
- Evidenziato se una scheda dispone al momento di gateway/connessione Internet.
