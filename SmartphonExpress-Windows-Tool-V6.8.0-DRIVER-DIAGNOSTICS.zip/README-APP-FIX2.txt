APP FIX 2
- Chrome: link diretto Google Enterprise MSI x64; installazione tramite msiexec /qn.
- VLC: link diretto a un mirror elencato dalla pagina ufficiale VideoLAN, perché get.videolan.org restituisce una pagina HTML di selezione mirror invece del binario quando interrogato direttamente.
- Firefox e 7-Zip invariati.
- Build PORTABLE FINAL invariata.
