SmartphonExpress Windows Tool v6.1.2

Aggiornamento download preconfigurato:
- URL: https://raw.githubusercontent.com/smartphonexpress/winutilmirror/main/attivo.rar
- salva l'archivio in %USERPROFILE%\Downloads\SmartphonExpress\attivo.rar
- estrae automaticamente il contenuto RAR nella stessa cartella
- apre Esplora file sul primo file estratto
- NON esegue automaticamente alcun file
- alla chiusura del tool elimina definitivamente:
  * attivo.rar
  * tutti i file estratti
  * la cartella SmartphonExpress
  senza passare dal Cestino.

Nota compilazione:
- aggiunto pacchetto NuGet SharpCompress 0.39.0 per l'estrazione RAR.
