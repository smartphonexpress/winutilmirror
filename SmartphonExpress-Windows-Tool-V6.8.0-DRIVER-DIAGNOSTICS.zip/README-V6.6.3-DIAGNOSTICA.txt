SmartphonExpress Windows Tool v6.6.3
====================================
Base: v6.5.3 REFINED INFO ICON

NOVITA PRINCIPALI
- Nuova sezione "Diagnostica e ripristino".
- SFC /Scannow con report finale leggibile.
- DISM /Online /Cleanup-Image /RestoreHealth con report finale.
- Reset componenti Windows Update: arresta i servizi interessati, rinomina SoftwareDistribution e catroot2 conservando le vecchie cartelle, quindi riavvia i servizi.
- Controllo WinRE tramite REAgentC /info.
- Diagnostica batteria dedicata: carica attuale, capacita di progetto, capacita a piena carica, salute stimata e valutazione testuale quando i dati firmware sono disponibili.
- Il check hardware/software rapido non mostra piu BatteryStatus come codice numerico; il risultato viene aperto anche in una finestra dedicata.
- Finestra report diagnostico con Copia e Salva TXT.
- Nuovo pulsante "Seleziona prestazioni": seleziona il gruppo prestazioni piu incisivo dopo conferma, lasciando esclusi i tweak rischiosi per sicurezza/compatibilita.
- Le nuove diagnostiche/riparazioni restano fuori da "Seleziona tutti" e si avviano solo se scelte esplicitamente.

NOTA
La build non e stata compilata nel container di preparazione perche l'ambiente non dispone del .NET SDK. Il pacchetto mantiene i consueti script BUILD-EXE.cmd / BUILD-PORTABLE-FINAL.cmd per la compilazione su Windows.


FIX 6.6.3
- Versione prodotto aggiornata correttamente a 6.6.3.
- Pulsanti rinominati: Seleziona consigliati / Seleziona prestazioni.
- Larghezza pulsanti aumentata per evitare testo troncato.
- Il profilo Prestazioni non seleziona automaticamente SFC, DISM, Windows Update reset, WinRE o diagnostica batteria.
