SmartphonExpress Windows Tool V4.10 - LICENSE FIX

Corretto il controllo licenze.

WINDOWS
- Non apre più cscript/slmgr in una finestra separata.
- Interroga SoftwareLicensingProduct tramite PowerShell/CIM.
- Scrive nel log nome prodotto, descrizione, partial key e LicenseStatus.
- Mostra un popup finale con ATTIVATO / NON ATTIVATO / altro stato.

OFFICE
- Cerca OSPP.VBS nelle installazioni Office 32/64 bit.
- Esegue cscript con output catturato direttamente dal programma.
- Scrive tutto il risultato nel log.
- Riconosce LICENSED quando presente.
- Per Microsoft 365 attivato tramite account, se OSPP non è disponibile o non rappresentativo,
  avvisa di verificare File > Account in Word/Excel.
