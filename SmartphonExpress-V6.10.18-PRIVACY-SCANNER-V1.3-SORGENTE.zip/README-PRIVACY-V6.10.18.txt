SmartphonExpress Windows Tool 6.10.18 / Privacy Scanner 1.3 BETA

Compilazione: estrarre tutto, eseguire source\BUILD-EXE.cmd con SDK .NET 8.
Aprire Outlook classico normalmente. Pulsante Privacy Scanner sotto Rimuovi OneDrive.
Il launcher e Program.cs restano quelli della 6.10.17, come pure preset e diagnostica.

Prima scansione: scegliere 3 o 6 caselle, periodo e Scansiona. Per le successive
attivare Incrementale: rilegge gli identificativi Outlook e analizza solo i messaggi
non ancora elaborati. Cache distinta per combinazione caselle/periodo; conserva la
finestra temporale iniziale e i risultati storici anche se la mail viene cancellata.
Per riallineare a una finestra mobile di 12 mesi o a cartelle spostate, eseguire
una scansione completa (checkbox disattivata). Un cambio EntryID puo duplicare
un messaggio nella cache incrementale. Non e una sincronizzazione bidirezionale.

Spuntare i mittenti e Proteggi spuntate per la lista bianca per singola casella.
Per revocare la protezione, spuntare le righe protette e Rimuovi protezione.
Lo storico delle richieste automatiche conserva l'ultimo tentativo per gruppo,
impedisce ripetizioni automatiche e distingue HTTP accettato/Outlook da conferma.
Solo recidivi indica gruppi con ultima mail oltre 14 giorni dalla richiesta;
non certifica una violazione o l'effettiva mancata disiscrizione.
Blocco assistito Outlook copia il mittente e indica come bloccarlo manualmente.
Bozza GDPR e Bozza revoca marketing aprono una mail Outlook senza destinatario:
inserire il contatto ufficiale dopo verifica. Nessun invio automatico di tali bozze.
Ricerca web casella apre Google con il solo indirizzo selezionato, previa conferma.
Non effettua una scansione automatica di data breach o del web.

Cache e preferenze cifrate con DPAPI CurrentUser sotto
%LOCALAPPDATA%\SmartphonExpress\PrivacyScanner\State. I report CSV/Excel non
sono cifrati; contengono dati personali e link individuali. Elimina cache locale
cancella soltanto cache di scansione, non storico e lista bianca.
Motore di disiscrizione 1.2 mantenuto: HTTPS POST One-Click o mailto dello stesso
dominio solo per newsletter con header idonei, previa conferma. Non garantisce
la legittimita del mittente. Evitare spam/phishing. Nessuna cancellazione di mail.

BETA: controllo statico sorgenti e integrita archivio; nessun test Outlook/Windows
ne compilazione .NET eseguiti in questo ambiente. Provare prima una newsletter nota.
