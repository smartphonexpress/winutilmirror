SmartphonExpress Privacy Scanner V1.2 BETA
Aprire Outlook classico e Avvia.cmd senza amministratore.
Scansionare, filtrare, spuntare le newsletter (anche tutte quelle visibili), quindi Disiscrivi spuntate. Controllare il riepilogo e confermare. Le spunte persistono cambiando filtro, ma non dopo una nuova scansione. Nessuna email viene eliminata.
Richieste automatiche solo per newsletter con header List-Unsubscribe: POST HTTPS One-Click (header List-Unsubscribe-Post) o mailto dello stesso dominio. Sono esclusi domini terzi, link non HTTPS, IP non pubblici e redirect automatici. Il controllo non costituisce una certificazione di sicurezza: confermare solo mittenti noti. Per link assistiti usare il pulsante apposito o cercare il sito ufficiale; evitare spam/phishing. Mailto usa l'account Outlook corrispondente. Esito HTTP accettato o richiesta affidata a Outlook NON certifica la disiscrizione.
Bozza GDPR copia il testo negli appunti: verificare il destinatario ufficiale. Esportare il report per conservare gli esiti della sessione; contiene dati personali e link individuali. Nessuno storico persistente automatico in questa beta.
Non verificato con Outlook/Windows in ambiente reale. Provare inizialmente su una sola newsletter conosciuta.

Integrazione: pulsante sotto OneDrive; risorsa incorporata, avvio delegato a Explorer. Compilare con source/BUILD-EXE.cmd. Non compilato in questo ambiente.
