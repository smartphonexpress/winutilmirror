SmartphonExpress Windows Tool v6.9.0 — Installer Audit

- Verificati i collegamenti di installazione di Chrome, Firefox, 7-Zip e VLC.
- VLC passa dal mirror fisso al dominio ufficiale get.videolan.org.
- Chrome MSI mantiene il pacchetto Enterprise ufficiale e aggiunge NOGOOGLEUPDATEPING=1 per evitare blocchi/timeout del ping Google Update in reti protette.
- Validazione minima del formato scaricato prima dell'esecuzione: MSI Compound File e EXE header MZ.
- Gli errori HTTP, download non valido e codici di uscita installer vengono propagati al riepilogo ESEGUI SELEZIONATI.
- Nessun fallback winget: gli installer restano diretti dai produttori.

Test consigliato: selezionare singolarmente Chrome, Firefox, 7-Zip e VLC su una VM pulita, poi provarli insieme con ESEGUI SELEZIONATI. Controllare il riepilogo finale: riuscite/errori deve corrispondere alle installazioni reali.
