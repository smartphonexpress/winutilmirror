SmartphonExpress Windows Tool v6.8.1

Correzioni principali:
- "Office: rimozione completa" esclusa dai preset Consigliato e Prestazioni: resta solo manuale.
- Rimozione Office verificata con GetHelpCmd / OfficeScrubScenario -OfficeVersion All e controllo finale dei residui rilevabili.
- Stato Office: Microsoft 365/Visio/Project subscription usa vnextdiag.ps1; Office LTSC/volume usa OSPP.VBS.
- Stato Windows: controllo strutturato SoftwareLicensingProduct con ApplicationID Windows + fallback slmgr /xpr.
- SFC e DISM RestoreHealth: corretta cattura output/timeout per evitare blocchi da buffer stdout/stderr; timeout estesi e report con exit code.
- Corretto anche il runner generico che redirigeva output senza leggerlo, potenziale causa di blocchi con processi verbosi.

Nota: compilare con BUILD-EXE.cmd su Windows/.NET 8 SDK.
