SmartphonExpress Windows Tool v6.8.8 — Windows Lifecycle Diagnostics

NUOVO
- Diagnostica sola lettura "versione / build / supporto Windows" nella scheda Diagnostica & Ripristino.
- Rileva ProductName, EditionID, DisplayVersion, CurrentBuildNumber e UBR.
- Distingue Windows 11 24H2 Home/Pro (fine supporto 13/10/2026) da Enterprise/Education (12/10/2027).
- Riconosce Windows 11 25H2 e Windows 10 22H2; per Windows 10 ricorda di verificare ESU/LTSC prima di concludere che il PC sia fuori supporto.
- Le preview sono esplicitamente trattate come facoltative: la funzione non installa aggiornamenti, non abilita Insider e non forza upgrade.

OBIETTIVO
Ridurre errori in consegna/diagnosi mostrando subito versione, build completa e stato del ciclo di supporto, senza introdurre tweak o modifiche di sicurezza.

TEST CONSIGLIATI
1. Windows 11 Home/Pro 24H2: deve mostrare scadenza 13/10/2026 e giorni residui.
2. Windows 11 Enterprise/Education 24H2: deve mostrare 12/10/2027, senza falso allarme Home/Pro.
3. Windows 11 25H2: deve risultare supportato secondo l'edizione.
4. Windows 10 22H2: deve indicare fine supporto standard e avvertire di verificare ESU/LTSC.
5. Verificare che l'operazione sia sola lettura e compaia nel report diagnostico aggregato.
